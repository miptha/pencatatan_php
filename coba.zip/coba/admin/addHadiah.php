<?php 
    $br = new lsp();
    if ($_SESSION['level'] != "Admin") {
    header("location:../index.php");
    }
    $table = "daftar_hadiah";
    $id = $br->validateHtml($_POST['id']);
    $waktu    = date("Y-m-d");
    if (isset($_POST['getSimpan'])) {
        $id  = $br->validateHtml($_POST['id']);
        $jenis_hadiah  = $br->validateHtml($_POST['jenis_hadiah']);
        $nama_hadiah = $br->validateHtml($_POST['nama_hadiah']);
        $nilai  = $br->validateHtml($_POST['nilai']);
        $foto         = $_FILES['foto'];

        if ($id == " " || $jenis_hadiah == " " || $nama_hadiah == " " || $nilai == " " ) {
            $response = ['response'=>'negative','alert'=>'lengkapi field'];
        }else{
            $response = $br->validateImage();
            if ($response['types'] == "true") {
                $value = "'$id','$jenis_hadiah','$nama_hadiah','$nilai','$response[image]'";

                $response = $br->insert($table,$value,"?page=viewHadiah");
            }
        } 
        
    }
 ?>
<div class="main-content" style="margin-top: 20px;">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" enctype="multipart/form-data">
                        <div class="card">
                        <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                            <div class="bg-overlay bg-overlay--blue"></div>
                            <h3>
                            <i class="zmdi zmdi-account-calendar"></i>Data Hadiah</h3>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card-body">
                                    <div class="form-group">
                                    <label for="">Id</label>
                                    <input type="text" style="font-weight: bold; color: red;" class="form-control" name="id" value="<?php echo $id; ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="">Jenis Hadiah</label>
                                    <select name="jenis_hadiah" class="form-control">
                                        <option value=" ">Pilih Hadiah</option>
                                        <option value="Hadiah Utama" name="jenis_hadiah">Hadiah Utama</option>
                                        <option value="Hadiah Hiburan" name="jenis_hadiah">Hadiah Hiburan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="">Nama Hadiah</label>
                                    <input type="text" class="form-control" name="nama_hadiah">
                                </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card-body">
                                    <div class="form-group">
                                    <label for="">Nilai</label>
                                    <input type="number" class="form-control" name="nilai">
                                </div>
                                <div class="form-group">
                                    <label for="">Foto</label>
                                    <input type="file" class="form-control" name="foto">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button name="getSimpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
                            <button type="reset" class="btn btn-danger"><i class="fa fa-eraser"></i> Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    $me       = new lsp();
    if ($_SESSION['level'] != "Admin") {
    header("location:../index.php");
    }
    $table    = "daftar_hadiah";
    $dataHadiah  = $me->select($table);

    $id = $me->validateHtml($_POST['id']);
    if (isset($_GET['delete'])) {
        $id       = $_GET['id'];
        $cek      = $me->selectCountWhere("daftar_peserta","nomor_kupon","id='$id'");
        // echo $cek['count'];
        if ($cek['count'] > 0) {
            $response = ['response'=>'negative','alert'=>'Hadiah ini sudah di pakai di barang tidak dapat di hapus'];
        }else{
        $where    = "id";
        $response = $me->delete($table,$where,$id,"?page=viewHadiah");
        }
    }

   

    if (isset($_POST['getUpdate'])) {
        $id = $me->validateHtml($_POST['id']);
        $hadiah      = $me->validateHtml($_POST['hadiah']);

        if ($_FILES['foto']['name'] == "") {
             $value    = "id='$id',hadiah='$hadiah'";
             $response = $me->update($table,$value,"id",$_GET['id'],"?page=viewHadiah");
        }else{
            $response = $me->validateImage();
            if ($response['types'] == "true") {
                $value = "id='$id',hadiah='$hadiah', foto_hadiah='$response[image]'";
                $response = $me->update($table,$value,"id",$_GET['id'],"?page=viewHadiah");
            }else{
                $response = ['response'=>'negative','alert'=>'Error Gambar'];
            }
        }
    }

    if (isset($_GET['edit'])) {
        $editData = $me->selectWhere($table,"id",$_GET['id']);
    }
    
 ?>
<section class="au-breadcrumb m-t-75">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="au-breadcrumb-content">
                       <div class="au-breadcrumb-left">
                            <ul class="list-unstyled list-inline au-breadcrumb__list">
                                <li class="list-inline-item active">
                                    <a href="#">Home</a>
                                </li>
                                <li class="list-inline-item seprate">
                                    <span>/</span>
                                </li>
                                <li class="list-inline-item">Data Hadiah</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="main-content" style="margin-top: -60px;">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                        <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                            <div class="bg-overlay bg-overlay--blue"></div>
                            <h3>
                            <i class="fas fa-gift"></i>Data Hadiah</h3>
                        </div>
                        <div class="card-body">
                        <a href="?page=addHadiah" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Hadiah</a>
                        </button>
                           <br>
                           <br>
                            <div class="table-responsive">
                               <table id="example" class="table table-borderless table-striped table-earning">
                                   <thead>
                                       <tr>
                                            <th>id</th>
                                            <th>Jenis Hadiah</th>
                                            <th>Nama Hadiah</th>
                                            <th>Nilai</th>
                                            <th>Foto</th>
                                            <th>Action</th>
                                       </tr>
                                   </thead>
                                   <tbody>
                                        <?php 
                                            $no = 1;
                                            foreach($dataHadiah as $ds){
                                         ?>
                                       <tr>
                                            <td><?= $ds['id'] ?></td>
                                            <td><?= $ds['jenis_hadiah'] ?></td>
                                            <td><?= $ds['nama_hadiah'] ?></td>
                                            <td><?= $ds['nilai'] ?></td>
                                            <td><img width="60" src="img/<?= $ds['foto'] ?>" alt=""></td>
                                            <td class="text-center">
                                            <div class="btn-group">
                                                    
                                                    <a href="?page=viewHadiahEdit&edit&id=<?= $ds['id'] ?>" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-info"><i class="fa fa-edit"></i></a>
                                                    
                                                </div>
                                            </td>
                                       </tr>
                                       <script src="vendor/jquery-3.2.1.min.js"></script>
                                       <script>
                                        $('#btnDelete<?php echo $no; ?>').click(function(e){
                                                      e.preventDefault();
                                                        swal({
                                                        title: "Hapus",
                                                        text: "Yakin Ingin menghapus?",
                                                        type: "error",
                                                        showCancelButton: true,
                                                        confirmButtonText: "Yes",
                                                        cancelButtonText: "Cancel",
                                                        closeOnConfirm: false,
                                                        closeOnCancel: true
                                                      }, function(isConfirm) {
                                                        if (isConfirm) {
                                                            window.location.href="?page=viewHadiah&delete&id=<?php echo $ds['id'] ?>";
                                                        }
                                                      });
                                                    });
                                        </script>
                                       <?php $no++; } ?>
                                   </tbody>
                               </table>
                           </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
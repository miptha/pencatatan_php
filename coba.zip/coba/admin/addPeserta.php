<?php 
    $br = new lsp();
    if ($_SESSION['level'] != "Admin") {
    header("location:../index.php");
    }
    $table = "daftar_peserta";    
    $autokode = $br->autokode("daftar_peserta","nomor_kupon","KP");
    $waktu    = date("Y-m-d");
    if (isset($_POST['getSimpan'])) {
        $nomor_kupon  = $br->validateHtml($_POST['nomor_kupon']);
        $nik  = $br->validateHtml($_POST['nik']);
        $nama  = $br->validateHtml($_POST['nama']);
        $alamat   = $_POST['alamat'];
        $telepon         = $br->validateHtml($_POST['telepon']);

        if ($nomor_kupon == " " || $nik == " " || $nama == " " || $alamat == " " || $telepon == " " ) {
            $response = ['response'=>'negative','alert'=>'lengkapi field'];
        }else{
            
            $value = "'$nomor_kupon','$nik','$nama','$alamat','$telepon'";

            $response = $br->insert($table,$value,"?page=viewPeserta");
        }
            
    }
 ?>
<div class="main-content" style="margin-top: 20px;">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <form method="post" enctype="multipart/form-data">
                        <div class="card">
                        <div class="au-card-title" style="background-image:url('images/bg-title-01.jpg');">
                            <div class="bg-overlay bg-overlay--blue"></div>
                            <h3>
                            <i class="zmdi zmdi-account-calendar"></i>Daftar Peserta</h3>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card-body">
                                    <div class="form-group">
                                    <label for="">Nomor Kupon</label>
                                    <input type="text" style="font-weight: bold; color: red;" class="form-control" name="nomor_kupon" value="<?php echo $autokode; ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="">NIK</label>
                                    <input type="text" placeholder="Nomor Induk Karyawan" class="form-control" name="nik" value="<?php echo @$_POST['nik'] ?>">
                                </div>
                                <div class="form-group">
                                    <label for="">Nama</label>
                                    <input type="text" placeholder="Nama" class="form-control" name="nama" value="<?php echo @$_POST['nama'] ?>">
                                </div>
                             
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card-body">
                                <div class="form-group">
                                    <label for="">Alamat</label>
                                    <input type="text" class="form-control" name="alamat">
                                </div>
                                <div class="form-group">
                                    <label for="">Telepon</label>
                                    <input type="number" class="form-control" name="telepon">
                                </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button name="getSimpan" class="btn btn-primary"><i class="fa fa-download"></i> Simpan</button>
                            <button type="reset" class="btn btn-danger"><i class="fa fa-eraser"></i> Reset</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
